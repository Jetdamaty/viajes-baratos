# ✈️ Viajes Baratos

Web desarrollada con React + Vite + TailwindCSS para ayudar a los viajeros a descubrir destinos económicos, consejos de ahorro y experiencias.

## Instrucciones

```bash
npm install
npm run dev
```

Despliegue recomendado: [Vercel](https://vercel.com)
